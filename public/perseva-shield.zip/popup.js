"use strict";
let snapshot = null;
const byId = id => document.getElementById(id);
const weekday = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];
function timerText(end) { const total = Math.max(0, Math.ceil((end - Date.now()) / 1000)); return `${String(Math.floor(total / 60)).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`; }
function paint(status) {
  snapshot = status;
  byId("status").classList.toggle("active", status.active);
  byId("status-label").textContent = status.active ? "Protecting focus" : "Ready";
  byId("headline").textContent = status.active ? "Your focus comes first." : "Make room for learning.";
  byId("subject").textContent = status.reasons?.length ? status.reasons.map(item => item.subject).join(" · ") : "Start a quiet 25 minutes.";
  byId("timer").classList.toggle("hidden", !status.session);
  if (status.session) byId("timer").textContent = timerText(status.session.endsAt);
  byId("start").classList.toggle("hidden", Boolean(status.session));
  byId("stop").classList.toggle("hidden", !status.session);
  const routines = status.routines.filter(item => item.enabled);
  byId("routine-count").textContent = `${routines.length} enabled`;
  byId("routines").replaceChildren();
  if (!routines.length) {
    const empty = document.createElement("p"); empty.className = "empty"; empty.textContent = "Your next good habit starts with a routine. Add one in Perseva, then sync this browser."; byId("routines").append(empty);
  }
  for (const routine of routines.slice(0, 8)) {
    const row = document.createElement("div"), info = document.createElement("div"), name = document.createElement("strong"), days = document.createElement("small"), time = document.createElement("time");
    row.className = "routine"; name.textContent = routine.subject; days.textContent = `${routine.days.map(day => weekday[day]).join(" · ")}${routine.block ? " · Blocking" : ""}${routine.remind ? " · Reminder" : ""}`;
    time.textContent = `${routine.start}–${routine.end}`; info.append(name, days); row.append(info, time); byId("routines").append(row);
  }
  if (routines.length > 8) { const more = document.createElement("p"); more.className = "empty"; more.textContent = `+ ${routines.length - 8} more in Perseva`; byId("routines").append(more); }
  byId("sync-note").textContent = status.lastSyncedAt ? `Last app sync: ${new Date(status.lastSyncedAt).toLocaleString()}. Routines use this device’s local time. A new app sync replaces the timer.` : "Open Perseva to sync your routines. Routines use this device’s local time.";
}
async function command(type) {
  try {
    const result = await chrome.runtime.sendMessage({type});
    if (!result?.ok) throw new Error(result?.error || "Unable to connect.");
    byId("error").textContent = ""; paint(result.payload);
  } catch (error) { byId("error").textContent = error.message; }
}
byId("start").addEventListener("click", () => command("MANUAL_FOCUS"));
byId("stop").addEventListener("click", () => command("STOP"));
byId("open").addEventListener("click", () => command("OPEN_APP"));
setInterval(() => { if (snapshot?.session) byId("timer").textContent = timerText(snapshot.session.endsAt); }, 1000);
setInterval(() => command("GET_STATUS"), 10000);
command("GET_STATUS");
