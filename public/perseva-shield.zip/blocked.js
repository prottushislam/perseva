"use strict";
const byId = id => document.getElementById(id);
let snapshot;
function updateCountdown() {
  if (!snapshot?.activeUntil) { byId("remaining").textContent = "Ready"; return; }
  const seconds = Math.max(0, Math.ceil((snapshot.activeUntil - Date.now()) / 1000));
  byId("remaining").textContent = `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
}
async function refresh() {
  try {
    const response = await chrome.runtime.sendMessage({type: "GET_STATUS"});
    if (!response?.ok) throw new Error(response?.error || "Unable to load your focus state.");
    snapshot = response.payload;
    byId("subject").textContent = snapshot.active ? snapshot.reasons.map(reason => reason.subject).join(" · ") : "Your focus time has ended";
    byId("badge-label").textContent = snapshot.active ? "Focus protected" : "Focus complete";
    byId("intro").textContent = snapshot.active ? "The next scroll can wait. Your focus session is keeping this distraction out of the way so you can return to what matters." : "You made room for what matters. Your scheduled protection has ended. Take a breath, choose your next step, and keep the momentum.";
    updateCountdown();
  } catch (error) { byId("error").textContent = error.message; }
}
byId("open").addEventListener("click", () => chrome.runtime.sendMessage({type: "OPEN_APP"}));
byId("study").addEventListener("click", () => location.assign("https://www.youtube.com/"));
setInterval(updateCountdown, 1000);
setInterval(refresh, 10000);
refresh();
