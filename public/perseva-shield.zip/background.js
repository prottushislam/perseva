"use strict";
importScripts("config.js", "shared.js");
const Core = PersevaCore;
const STORAGE_KEY = "persevaState";
const SOCIAL_PATTERNS = Core.SERVICES.map(service => `*://*.${service}.com/*`);
let queue = Promise.resolve();
let ruleSignature = null;

function serial(task) {
  const result = queue.then(task, task);
  queue = result.catch(error => console.error("Perseva:", error));
  return result;
}
async function readState() {
  const stored = (await chrome.storage.local.get(STORAGE_KEY))[STORAGE_KEY];
  if (!stored) return Core.defaults();
  try {
    const checked = Core.normalizeSync({routines: stored.routines, blocking: stored.blocking, session: stored.session}, Date.now());
    // Keep an expired deadline until reconciliation records completion once.
    if (stored.session && Number.isFinite(stored.session.endsAt) && stored.session.endsAt <= Date.now()) checked.session = stored.session;
    return {...checked, notified: stored.notified && typeof stored.notified === "object" ? stored.notified : {}, lastSyncedAt: stored.lastSyncedAt || null};
  } catch (error) {
    console.error("Perseva settings were invalid; using safe defaults.", error);
    return Core.defaults();
  }
}
async function writeState(state) { await chrome.storage.local.set({[STORAGE_KEY]: state}); }
function status(state, now = Date.now()) {
  return {connected: true, ...Core.evaluate(state, now), blocking: state.blocking, routines: state.routines, lastSyncedAt: state.lastSyncedAt};
}
function contentStatus(state, current) {
  return {active: current.active, activeUntil: current.activeUntil, blocking: state.blocking};
}
async function notify(id, title, message) {
  try {
    await chrome.notifications.create(id, {type: "basic", iconUrl: "icons/icon128.png", title, message, priority: 0});
  } catch (error) { console.warn("Notification unavailable:", error); }
}
async function updateRules(state, current) {
  const rules = Core.buildRules(state.blocking, current.active);
  const signature = JSON.stringify(rules);
  if (signature !== ruleSignature) {
    await chrome.declarativeNetRequest.updateDynamicRules({removeRuleIds: [100, 101, 102, 103], addRules: rules});
    ruleSignature = signature;
  }
}
async function guardTab(tabId, rawUrl, state, current) {
  if (!current.active) return;
  const service = Core.blockedService(rawUrl, state.blocking);
  if (service) {
    try { await chrome.tabs.update(tabId, {url: chrome.runtime.getURL(`blocked.html?service=${service}`)}); }
    catch (_) { /* Tab may have closed during navigation. */ }
  }
}
async function broadcast(state, current) {
  const tabs = await chrome.tabs.query({url: SOCIAL_PATTERNS});
  await Promise.all(tabs.map(async tab => {
    await guardTab(tab.id, tab.url, state, current);
    try { await chrome.tabs.sendMessage(tab.id, {type: "PERSEVA_STATE", payload: contentStatus(state, current)}); } catch (_) {}
  }));
}
async function reconcile({broadcastTabs = false} = {}) {
  const now = Date.now(), state = await readState();
  let dirty = false;
  if (state.session && state.session.endsAt <= now) {
    const end = state.session;
    state.session = null; dirty = true;
    // No stale completion notifications after returning days later.
    if (now - end.endsAt <= 5 * 60000) await notify(`session-${end.endsAt}`, "Focus session complete", `${end.subject} is complete. Take a moment to reset.`);
  }
  const current = Core.evaluate(state, now);
  for (const routine of current.activeRoutines) {
    if (!routine.remind || state.notified[routine.key] || now - routine.start > 5 * 60000) continue;
    state.notified[routine.key] = now; dirty = true;
    await notify(`routine-${routine.key}`, "Time for your study routine", `${routine.subject} · until ${new Date(routine.end).toLocaleTimeString([], {hour: "2-digit", minute: "2-digit"})}`);
  }
  for (const [key, date] of Object.entries(state.notified)) if (typeof date !== "number" || date < now - 8 * 86400000) { delete state.notified[key]; dirty = true; }
  if (dirty) await writeState(state);
  await updateRules(state, current);
  if (current.nextChange) {
    const boundary = await chrome.alarms.get("perseva-boundary");
    if (!boundary || boundary.scheduledTime !== current.nextChange) await chrome.alarms.create("perseva-boundary", {when: current.nextChange});
  }
  else await chrome.alarms.clear("perseva-boundary");
  if (!(await chrome.alarms.get("perseva-reconcile"))) await chrome.alarms.create("perseva-reconcile", {periodInMinutes: 1});
  await chrome.action.setBadgeText({text: current.active ? "ON" : ""});
  await chrome.action.setBadgeBackgroundColor({color: "#cafa73"});
  if (broadcastTabs) await broadcast(state, current);
  return status(state, now);
}
function isApp(sender) {
  try { return Boolean(sender.tab) && PERSEVA_APP_ORIGINS.includes(new URL(sender.url).origin); } catch (_) { return false; }
}
function isInternal(sender) { return !sender.tab && typeof sender.url === "string" && sender.url.startsWith(chrome.runtime.getURL("")); }
function isExtensionPage(sender) { return typeof sender.url === "string" && sender.url.startsWith(chrome.runtime.getURL("")); }
function isSocial(sender) { return Boolean(sender.tab) && Boolean(Core.getService(sender.url)); }

chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (!message || typeof message !== "object" || typeof message.type !== "string") return false;
  const allowed = (isApp(sender) && ["SYNC", "PING"].includes(message.type)) ||
    (isInternal(sender) && ["GET_STATUS", "MANUAL_FOCUS", "STOP"].includes(message.type)) ||
    (isExtensionPage(sender) && ["GET_STATUS", "OPEN_APP"].includes(message.type)) ||
    (isSocial(sender) && ["CONTENT_STATUS", "CHECK_ROUTE"].includes(message.type));
  if (!allowed) { respond({ok: false, error: "Sender is not authorized."}); return false; }
  serial(async () => {
    if (message.type === "SYNC") {
      const data = Core.normalizeSync(message.payload);
      // The app may clear its finished timer before the browser alarm is delivered.
      // Reconcile the prior deadline first so its completion is recorded exactly once.
      await reconcile();
      const state = await readState();
      await writeState({...state, ...data, lastSyncedAt: Date.now()});
      return {ok: true, payload: await reconcile({broadcastTabs: true})};
    }
    if (message.type === "MANUAL_FOCUS" || message.type === "STOP") {
      const state = await readState();
      state.session = message.type === "MANUAL_FOCUS" ? {subject: "Focused study", endsAt: Date.now() + 25 * 60000} : null;
      await writeState(state);
      return {ok: true, payload: await reconcile({broadcastTabs: true})};
    }
    if (message.type === "OPEN_APP") await chrome.tabs.create({url: PERSEVA_APP_URL});
    const current = await reconcile();
    if (message.type === "CHECK_ROUTE") {
      // A page never supplies the privileged destination: inspect its actual tab URL.
      const tab = await chrome.tabs.get(sender.tab.id);
      await guardTab(tab.id, tab.url, await readState(), current);
    }
    return {ok: true, payload: isSocial(sender) ? contentStatus(await readState(), current) : current};
  }).then(respond, error => respond({ok: false, error: error.message || "Perseva could not update."}));
  return true;
});

const routeChanged = details => {
  if (details.frameId !== 0 || !Core.getService(details.url)) return;
  serial(async () => { const current = await reconcile(); await guardTab(details.tabId, details.url, await readState(), current); });
};
const navigationFilter = {url: Core.SERVICES.map(service => ({hostSuffix: `${service}.com`}))};
chrome.webNavigation.onCommitted.addListener(routeChanged, navigationFilter);
chrome.webNavigation.onHistoryStateUpdated.addListener(routeChanged, navigationFilter);
chrome.webNavigation.onReferenceFragmentUpdated.addListener(routeChanged, navigationFilter);
chrome.tabs.onUpdated.addListener((tabId, changes, tab) => { if (changes.url) routeChanged({frameId: 0, tabId, url: changes.url}); });
chrome.alarms.onAlarm.addListener(alarm => { if (alarm.name.startsWith("perseva-")) serial(() => reconcile({broadcastTabs: true})); });
chrome.runtime.onInstalled.addListener(() => serial(() => reconcile({broadcastTabs: true})));
chrome.runtime.onStartup.addListener(() => serial(() => reconcile({broadcastTabs: true})));
chrome.notifications.onClicked.addListener(() => chrome.tabs.create({url: PERSEVA_APP_URL}));
serial(() => reconcile({broadcastTabs: true}));
