"use strict";
(() => {
  if (window.top !== window) return;
  let current = {active: false, blocking: {...PersevaCore.DEFAULT_BLOCKING}}, lastUrl = location.href, refreshing = false;
  function enforce() {
    if (!current.active || !PersevaCore.blockedService(location.href, current.blocking)) return;
    // Pause already-rendered media while the browser-level route guard redirects.
    document.querySelectorAll("video,audio").forEach(media => media.pause());
    chrome.runtime.sendMessage({type: "CHECK_ROUTE"}).catch(() => {});
  }
  async function refresh() {
    if (refreshing) return;
    refreshing = true;
    try {
      const response = await chrome.runtime.sendMessage({type: "CONTENT_STATUS"});
      if (response?.ok) { current = response.payload; enforce(); }
    } catch (_) {} finally { refreshing = false; }
  }
  chrome.runtime.onMessage.addListener(message => {
    if (message?.type === "PERSEVA_STATE") { current = message.payload; enforce(); }
  });
  window.addEventListener("pageshow", refresh);
  window.addEventListener("popstate", refresh);
  window.addEventListener("hashchange", refresh);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) refresh(); });
  document.addEventListener("click", event => {
    if (!current.active) return;
    const anchor = event.target instanceof Element ? event.target.closest("a[href]") : null;
    if (anchor && PersevaCore.blockedService(anchor.href, current.blocking)) {
      event.preventDefault(); event.stopImmediatePropagation();
      location.assign(chrome.runtime.getURL(`blocked.html?service=${PersevaCore.blockedService(anchor.href, current.blocking)}`));
    }
  }, true);
  // History APIs run in the page's isolated world; do not try to monkey-patch them.
  // This light fallback complements webNavigation for restored/cached SPA pages.
  setInterval(() => {
    if (location.href !== lastUrl) { lastUrl = location.href; refresh(); }
    if (current.activeUntil && Date.now() >= current.activeUntil) refresh();
  }, 1000);
  refresh();
})();
