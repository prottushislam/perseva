"use strict";
globalThis.PERSEVA_APP_ORIGINS = Object.freeze([
  "https://perseva-study.prottushislam17.chatgpt.site",
  "http://localhost:3000",
  "http://127.0.0.1:3000",
  "http://localhost:5173"
]);
globalThis.PERSEVA_APP_URL = "https://perseva-study.prottushislam17.chatgpt.site/";
