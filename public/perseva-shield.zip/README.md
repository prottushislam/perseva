# Perseva companion extension

Desktop Chrome / Microsoft Edge, Manifest V3. This companion adds browser filtering and background reminders to [Perseva](https://perseva-study.prottushislam17.chatgpt.site/).

## Install locally

1. Unzip this folder to a permanent location.
2. Open `chrome://extensions` (Chrome) or `edge://extensions` (Edge).
3. Enable **Developer mode**, choose **Load unpacked**, and select the folder containing `manifest.json`.
4. Pin **Perseva — Study Focus**, then reload the Perseva app tab. Open the app to sync saved routines and session settings. The popup displays the last successful sync.
5. Allow browser notifications in your operating system if you want reminders. This package is an unpacked companion; it has not been submitted to a browser store.

## What works

- A 25-minute timer can be started and stopped from the extension popup.
- The app sends weekly routines, blocking choices and its current timer to this extension while the app is open. They are saved locally and survive browser restarts.
- During a timer or a routine with blocking enabled, selected filters redirect YouTube `/shorts`, Instagram `/reel` and `/reels`, Facebook `/reel` and `/reels`, and the TikTok website to a focus screen.
- Ordinary YouTube `/watch`, search, channels and study videos remain available. This is route filtering, not a video-content classifier: a short video accessible on `/watch` remains accessible. The extension does not distinguish educational from entertainment videos.
- Both direct navigation and in-site history changes are checked. Open distracting tabs are checked when protection starts.
- Saved reminder routines and timer completions use extension alarms and desktop notifications after the Perseva tab closes, as long as the browser is running and notifications are permitted.

## Limits and expectations

- This extension works within the browser where it is installed. It cannot block native phone apps or other browsers. Disabled extensions, private windows without extension access, and different browser profiles are outside its control.
- Browser alarms are not exact timers: Chrome can delay them, a sleeping device is not awakened, and a fully exited browser cannot be relied on for local reminders. State is corrected when the browser/worker next runs. Reminders more than five minutes late are skipped to avoid stale notifications.
- The timer display derives from an absolute deadline rather than counting background seconds. Alarms operate at a minimum 30-second interval in installed Chrome builds; short tests in unpacked mode can behave differently.
- Routines use the device's local clock and selected weekdays. Overnight routines are intentionally rejected. Overlapping routines keep filtering enabled until every active blocking routine and timer has ended. The popup's **Stop timer** does not disable an active routine.
- The app syncs settings on opening/saving. Changes made elsewhere do not reach a closed app automatically. Reopen the app to sync. Any app `SYNC` replaces the extension timer; `session: null` also stops a timer started in the popup.
- Websites can change their navigation behavior. Filtering covers the documented path routes above; feed-embedded videos and renamed routes are not promised. Already-rendered content may appear briefly before an SPA redirect.
- Content scripts in tabs already open when the extension was installed or reloaded may need a page reload. Browser navigation listeners still handle subsequent route changes.

## App connection

Only this exact production origin is permitted:

`https://perseva-study.prottushislam17.chatgpt.site`

This development package also permits `http://localhost:3000`, `http://127.0.0.1:3000`, and `http://localhost:5173` for local QA. A page served at any of those local addresses can replace extension settings. Remove these development entries from both `config.js` and `manifest.json` for a production-store-only build.

The app posts to its own origin:

```js
window.postMessage({
  source: 'perseva-app', type: 'SYNC',
  payload: {
    routines: [{id:'biology', subject:'Biology', start:'18:00', end:'19:00', days:[1,2,3,4,5], enabled:true, block:true, remind:true}],
    blocking: {youtube:true, instagram:true, facebook:true, tiktok:true},
    session: null // Or {endsAt: Date.now() + 25 * 60000, subject:'Biology'}
  }
}, location.origin);
window.postMessage({source:'perseva-app', type:'PING'}, location.origin);
```

The response has `source: 'perseva-extension'`, `type: 'STATUS'`, and `payload.connected` / `payload.active`. A `payload.error` means an update failed; the app must display it rather than claim successful sync. Routines require all shown fields. Days use Sunday = 0 through Saturday = 6; times require zero-padded `HH:mm`. Optional session `startedAt` and `duration` are validated but are not used for timing. All code is bundled; no remotely downloaded code runs.

## Verification

Run `node tests/core.test.cjs` for validation, scheduling and URL coverage; `node tests/background.test.cjs` for the mocked worker integration; and `node tests/bridge.test.cjs` for the app connection trust boundary. JavaScript can also be checked with `node --check FILE`.

Before publishing, manually verify on both Chrome and Edge: direct URLs; in-site history navigation; back/forward restore; routine start with a distracting tab already open; timer ending with app tab closed; restart inside/outside a routine; device sleep across a boundary; overlap; weekday rollover; notification denial; extension reload and app reconnection. Browser UI and real third-party sites have not been exercised by the isolated tests.

## API references

- [Chrome alarms: timing, sleep and persistence](https://developer.chrome.com/docs/extensions/reference/api/alarms)
- [Manifest V3 service-worker lifecycle](https://developer.chrome.com/docs/extensions/develop/concepts/service-workers/lifecycle)
- [Declarative Net Request: dynamic rules and network/cache limits](https://developer.chrome.com/docs/extensions/reference/api/declarativeNetRequest)
- [Navigation events, including SPA history changes](https://developer.chrome.com/docs/extensions/reference/api/webNavigation)
- [Extension notifications](https://developer.chrome.com/docs/extensions/reference/api/notifications)
- [Supported Microsoft Edge extension APIs](https://learn.microsoft.com/en-us/microsoft-edge/extensions/developer-guide/api-support)

Native app restriction would be a separate product: [Apple Family Controls](https://developer.apple.com/documentation/familycontrols) needs native authorization and distribution entitlement; [Android managed app suspension](https://developer.android.com/work/dpc/security) requires device/profile-owner privileges. This web extension does not implement either.
