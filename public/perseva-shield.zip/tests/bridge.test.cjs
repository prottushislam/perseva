"use strict";
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const root = path.resolve(__dirname, "..");
const origin = "https://perseva-study.prottushislam17.chatgpt.site";
function harness(pageOrigin = origin, frame = false) {
  const listeners = [], posts = [], requests = [];
  const window = {addEventListener(type, fn) {listeners.push(fn);}, postMessage(message, target) {posts.push({message, target});}};
  window.top = frame ? {} : window;
  const context = vm.createContext({window, location: {origin: pageOrigin}, URL, Date, console, chrome: {runtime: {async sendMessage(message) {requests.push(message); return {ok: true, payload: {connected: true, active: true}};}}}});
  for (const file of ["config.js", "shared.js", "app-bridge.js"]) vm.runInContext(fs.readFileSync(path.join(root, file), "utf8"), context);
  return {listeners, posts, requests, window};
}
(async () => {
  assert.equal(harness("https://evil.test").listeners.length, 0);
  assert.equal(harness(origin, true).listeners.length, 0);
  const h = harness();
  const ping = {source: "perseva-app", type: "PING"};
  await h.listeners[0]({source: {}, origin, data: ping});
  await h.listeners[0]({source: h.window, origin: "https://evil.test", data: ping});
  await h.listeners[0]({source: h.window, origin, data: {source: "evil", type: "PING"}});
  assert.equal(h.requests.length, 0);
  await h.listeners[0]({source: h.window, origin, data: ping});
  assert.equal(h.requests[0].type, "PING");
  assert.equal(h.posts[0].message.source, "perseva-extension");
  assert.equal(h.posts[0].message.type, "STATUS");
  assert.equal(h.posts[0].target, origin);
  const settings = {routines: [], blocking: {youtube: true, instagram: true, facebook: true, tiktok: true}, session: null};
  await h.listeners[0]({source: h.window, origin, data: {source: "perseva-app", type: "SYNC", payload: settings}});
  assert.equal(h.requests[1].type, "SYNC"); assert.equal(h.requests[1].payload.session, null);
  await h.listeners[0]({source: h.window, origin, data: {source: "perseva-app", type: "SYNC", payload: {...settings, unsafe: true}}});
  assert.equal(h.requests.at(-1).type, "PING"); // Validation failure does not replace state.
  assert.ok(h.posts.at(-1).message.payload.error);
  assert.equal(h.posts.at(-1).message.payload.active, true); // Never claim a still-active blocker is off.
  for (const local of ["http://localhost:3000", "http://127.0.0.1:3000", "http://localhost:5173"]) assert.equal(harness(local).listeners.length, 1);
  console.log("PASS bridge exact-origin, top-frame, sender, schema, sync, ping and failure-state checks");
})().catch(error => {console.error(error); process.exitCode = 1;});
