"use strict";
const assert = require("node:assert/strict");
const Core = require("../shared.js");
let count = 0;
function test(name, fn) { fn(); count++; console.log(`PASS ${name}`); }
const now = new Date(2026, 9, 9, 10, 30).getTime();
const day = new Date(now).getDay();
const routine = {id: "biology", subject: "Biology", start: "10:00", end: "11:00", days: [day], enabled: true, block: true, remind: true};
const data = () => ({routines: [{...routine, days: [...routine.days]}], blocking: {...Core.DEFAULT_BLOCKING}, session: null});
test("valid payload is cloned and trimmed", () => {
  const value = data(); value.routines[0].subject = " Biology ";
  const result = Core.normalizeSync(value, now);
  assert.equal(result.routines[0].subject, "Biology");
  assert.notEqual(result.routines, value.routines);
});
test("rejects unknown keys, malformed data and missing fields", () => {
  for (const mutate of [x => x.bad = true, x => x.routines = {}, x => x.blocking.youtube = "yes", x => delete x.session, x => delete x.routines[0].block, x => x.routines[0].subject = "", x => x.routines[0].id = 9, x => x.routines[0].days = [day, day], x => x.routines[0].days = [-1], x => x.routines[0].days = [], x => x.routines.push({...x.routines[0]})]) {
    const value = data(); mutate(value); assert.throws(() => Core.normalizeSync(value, now));
  }
});
test("rejects overnight, equal, malformed and impossible times", () => {
  for (const [start, end] of [["23:00", "01:00"], ["10:00", "10:00"], ["9:00", "11:00"], ["24:00", "25:00"], ["09:61", "12:00"]]) {
    const value = data(); Object.assign(value.routines[0], {start, end}); assert.throws(() => Core.normalizeSync(value, now));
  }
});
test("enforces session deadline, subject and optional metadata", () => {
  const value = data(); value.session = {endsAt: now + 60000, subject: "Study", startedAt: now, duration: 25};
  assert.equal(Core.normalizeSync(value, now).session.endsAt, now + 60000);
  for (const session of [{endsAt: "tomorrow", subject: "Study"}, {endsAt: now + 8 * 86400000, subject: "Study"}, {endsAt: now + 60000, subject: "Study", startedAt: now + 120000}, {endsAt: now + 60000, subject: "Study", duration: -5}]) {
    assert.throws(() => Core.normalizeSync({...data(), session}, now));
  }
  assert.equal(Core.normalizeSync({...data(), session: {endsAt: now - 1, subject: "Study"}}, now).session, null);
});
test("routine uses exact local start-inclusive end-exclusive interval", () => {
  const state = data();
  assert.equal(Core.evaluate(state, new Date(2026, 9, 9, 9, 59, 59).getTime()).active, false);
  assert.equal(Core.evaluate(state, new Date(2026, 9, 9, 10).getTime()).active, true);
  assert.equal(Core.evaluate(state, now).active, true);
  assert.equal(Core.evaluate(state, new Date(2026, 9, 9, 11).getTime()).active, false);
});
test("weekday, disabled and reminder-only routines do not accidentally block", () => {
  for (const change of [{days: [(day + 1) % 7]}, {enabled: false}, {block: false}]) {
    const state = data(); Object.assign(state.routines[0], change); assert.equal(Core.evaluate(state, now).active, false);
  }
});
test("overlapping routine and timer union preserves longer restriction", () => {
  const state = data(); state.routines.push({...routine, id: "math", end: "11:30"}); state.session = {endsAt: now + 10 * 60000, subject: "Review"};
  const result = Core.evaluate(state, now);
  assert.equal(result.reasons.length, 3);
  assert.equal(result.activeUntil, new Date(2026, 9, 9, 11, 30).getTime());
  assert.equal(result.nextChange, state.session.endsAt);
});
test("timer resumes from deadline, expires, and obeys selected services", () => {
  const state = {routines: [], blocking: {...Core.DEFAULT_BLOCKING}, session: {endsAt: now + 60000, subject: "Study"}};
  assert.equal(Core.evaluate(state, now).active, true);
  assert.equal(Core.evaluate(state, now + 60000).active, false);
  for (const key of Core.SERVICES) state.blocking[key] = false;
  assert.equal(Core.evaluate(state, now).active, false);
});
test("next weekly boundary is calculated across the week rollover", () => {
  const state = data();
  assert.equal(Core.evaluate(state, new Date(2026, 9, 9, 12).getTime()).nextChange, new Date(2026, 9, 16, 10).getTime());
});
const routes = [
  ["https://www.youtube.com/shorts", "youtube"], ["https://m.youtube.com/shorts/abc?x=1", "youtube"],
  ["https://youtube.com/%73horts/abc", "youtube"], ["https://www.instagram.com/reel/abc/", "instagram"],
  ["https://instagram.com/reels/?next=1", "instagram"], ["https://m.facebook.com/reel/123", "facebook"],
  ["https://facebook.com/reels", "facebook"], ["https://www.tiktok.com/@study/video/123", "tiktok"]
];
test("route guard blocks known short-form paths and TikTok", () => {
  for (const [url, service] of routes) assert.equal(Core.blockedService(url, Core.DEFAULT_BLOCKING), service, url);
});
test("normal study routes and lookalike domains stay available", () => {
  for (const url of ["https://youtube.com/watch?v=abc", "https://youtube.com/results?search_query=shorts", "https://youtube.com/shortstory", "https://youtube.com/shortsleeves", "https://instagram.com/direct/inbox", "https://facebook.com/watch", "https://youtube.com.evil.test/shorts/x", "https://evilyoutube.com/shorts", "https://example.com/?url=https://youtube.com/shorts", "chrome://extensions", "file:///shorts", "not a URL"]) assert.equal(Core.blockedService(url, Core.DEFAULT_BLOCKING), null, url);
  assert.equal(Core.blockedService("https://youtube.com/shorts/abc", {...Core.DEFAULT_BLOCKING, youtube: false}), null);
});
test("DNR rules have stable IDs, explicit host boundaries and main-frame scope", () => {
  const rules = Core.buildRules(Core.DEFAULT_BLOCKING, true);
  assert.deepEqual(rules.map(rule => rule.id), [100, 101, 102, 103]);
  for (const rule of rules) assert.deepEqual(rule.condition.resourceTypes, ["main_frame"]);
  for (const [url, service] of routes.filter(([url]) => !url.includes("%73"))) {
    const rule = rules[Core.SERVICES.indexOf(service)];
    assert.ok(!rule.condition.regexFilter || new RegExp(rule.condition.regexFilter, "i").test(url));
  }
  assert.equal(new RegExp(rules[0].condition.regexFilter, "i").test("https://youtube.com/shortsleeves"), false);
  assert.deepEqual(Core.buildRules(Core.DEFAULT_BLOCKING, false), []);
  assert.equal(Core.buildRules({...Core.DEFAULT_BLOCKING, tiktok: false}, true).length, 3);
});
console.log(`${count} core test groups passed.`);
