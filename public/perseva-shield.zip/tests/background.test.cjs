"use strict";
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const directory = path.resolve(__dirname, "..");
let now = new Date(2026, 9, 9, 10, 30).getTime(), count = 0;
const store = {}, alarms = new Map(), notifications = [], redirects = [], opened = [], ruleUpdates = [];
const tab = {id: 4, url: "https://www.youtube.com/watch?v=study"};
const clone = value => structuredClone(value);
const event = () => ({listeners: [], addListener(fn) {this.listeners.push(fn);}});
const chrome = {
  storage: {local: {async get(key) {return {[key]: clone(store[key])};}, async set(value) {Object.assign(store, clone(value));}}},
  alarms: {onAlarm: event(), async get(name) {return alarms.get(name);}, async create(name, value) {alarms.set(name, {...value, name, scheduledTime: value.when || now + value.periodInMinutes * 60000});}, async clear(name) {return alarms.delete(name);}},
  notifications: {onClicked: event(), async create(id, value) {notifications.push({id, ...value});}},
  declarativeNetRequest: {async updateDynamicRules(value) {ruleUpdates.push(clone(value));}},
  action: {async setBadgeText() {}, async setBadgeBackgroundColor() {}},
  tabs: {onUpdated: event(), async query() {return [clone(tab)];}, async update(id, value) {redirects.push({id, ...value}); tab.url = value.url;}, async sendMessage() {}, async get() {return clone(tab);}, async create(value) {opened.push(value);}},
  webNavigation: {onCommitted: event(), onHistoryStateUpdated: event(), onReferenceFragmentUpdated: event()},
  runtime: {onMessage: event(), onInstalled: event(), onStartup: event(), getURL(value) {return `chrome-extension://test/${value}`;}}
};
class MockDate extends Date { constructor(...args) {super(...(args.length ? args : [now]));} static now() {return now;} }
const context = vm.createContext({chrome, Date: MockDate, URL, console, Promise, setTimeout});
context.importScripts = (...files) => files.forEach(file => vm.runInContext(fs.readFileSync(path.join(directory, file), "utf8"), context, {filename: file}));
const flush = () => vm.runInContext("queue", context);
const extensionSender = {url: "chrome-extension://test/popup.html"};
const appSender = {url: "https://perseva-study.prottushislam17.chatgpt.site/", tab: {id: 8}};
const msg = (type, sender = extensionSender, payload) => new Promise(resolve => {chrome.runtime.onMessage.listeners[0]({type, payload}, sender, resolve);});
async function test(name, fn) {await fn(); count++; console.log(`PASS ${name}`);}
(async () => {
  vm.runInContext(fs.readFileSync(path.join(directory, "background.js"), "utf8"), context, {filename: "background.js"});
  await flush();
  await test("startup clears stale managed rules and creates recovery alarm", async () => {
    assert.equal(ruleUpdates[0].addRules.length, 0); assert.ok(alarms.has("perseva-reconcile"));
  });
  await test("unknown sender cannot alter focus state", async () => {
    assert.equal((await msg("MANUAL_FOCUS", {url: "https://evil.test/", tab: {id: 6}})).ok, false);
    assert.equal((await msg("SYNC", {...appSender, url: "https://perseva-study.prottushislam17.chatgpt.site.evil.test/"}, {})).ok, false);
  });
  await test("manual focus stores absolute deadline and all four rules", async () => {
    const result = await msg("MANUAL_FOCUS");
    assert.equal(result.ok, true); assert.equal(result.payload.active, true);
    assert.equal(store.persevaState.session.endsAt, now + 25 * 60000);
    assert.equal(ruleUpdates.at(-1).addRules.length, 4);
  });
  await test("status reads do not postpone an existing boundary alarm", async () => {
    const original = alarms.get("perseva-boundary");
    now += 1000; await msg("GET_STATUS");
    assert.equal(alarms.get("perseva-boundary"), original);
  });
  await test("SPA history transition redirects a Shorts route", async () => {
    tab.url = "https://youtube.com/shorts/abc";
    chrome.webNavigation.onHistoryStateUpdated.listeners[0]({tabId: 4, frameId: 0, url: tab.url}); await flush();
    assert.equal(redirects.at(-1).url, "chrome-extension://test/blocked.html?service=youtube");
  });
  await test("fresh app sync rejects malformed payload without erasing active timer", async () => {
    const result = await msg("SYNC", appSender, {routines: [], blocking: {youtube: "yes"}, session: null});
    assert.equal(result.ok, false); assert.ok(store.persevaState.session);
  });
  const settings = () => ({routines: [], blocking: {youtube: true, instagram: true, facebook: true, tiktok: true}, session: null});
  await test("app null session explicitly stops popup timer", async () => {
    const result = await msg("SYNC", appSender, settings());
    assert.equal(result.ok, true); assert.equal(result.payload.active, false); assert.equal(store.persevaState.session, null);
    assert.equal(ruleUpdates.at(-1).addRules.length, 0);
  });
  await test("routine starts with tab closed, notifies once, and covers existing short-form tab", async () => {
    const setting = settings(); setting.routines = [{id: "biology", subject: "Biology", start: "10:31", end: "11:00", days: [new Date(now).getDay()], enabled: true, block: true, remind: true}];
    await msg("SYNC", appSender, setting);
    now = new Date(2026, 9, 9, 10, 31).getTime(); tab.url = "https://facebook.com/reel/123";
    chrome.alarms.onAlarm.listeners[0]({name: "perseva-boundary"}); await flush();
    assert.equal(redirects.at(-1).url, "chrome-extension://test/blocked.html?service=facebook");
    const before = notifications.length; assert.equal(notifications.at(-1).title, "Time for your study routine");
    await msg("GET_STATUS"); assert.equal(notifications.length, before);
  });
  await test("stopping timer preserves a concurrently active routine", async () => {
    await msg("MANUAL_FOCUS"); const result = await msg("STOP");
    assert.equal(result.payload.active, true); assert.equal(result.payload.session, null);
  });
  await test("routine ends and persistent rules are removed", async () => {
    now = new Date(2026, 9, 9, 11).getTime(); chrome.alarms.onAlarm.listeners[0]({name: "perseva-boundary"}); await flush();
    assert.equal(ruleUpdates.at(-1).addRules.length, 0);
  });
  await test("missing alarm is restored after startup and expired timer notifies once", async () => {
    await msg("MANUAL_FOCUS"); now += 25 * 60000 + 1000; alarms.clear();
    chrome.runtime.onStartup.listeners[0](); await flush();
    assert.ok(alarms.has("perseva-reconcile")); assert.equal(store.persevaState.session, null);
    const before = notifications.length; assert.equal(notifications.at(-1).title, "Focus session complete");
    await msg("GET_STATUS"); assert.equal(notifications.length, before);
  });
  await test("stale completion is suppressed after a long sleep", async () => {
    await msg("MANUAL_FOCUS"); const before = notifications.length; now += 3 * 3600000;
    chrome.runtime.onStartup.listeners[0](); await flush(); assert.equal(notifications.length, before); assert.equal(store.persevaState.session, null);
  });
  await test("app null sync at deadline cannot erase a pending completion notification", async () => {
    await msg("MANUAL_FOCUS"); const before = notifications.length;
    now += 25 * 60000 + 1000;
    const result = await msg("SYNC", appSender, settings());
    assert.equal(result.ok, true); assert.equal(store.persevaState.session, null);
    assert.equal(notifications.length, before + 1);
    assert.equal(notifications.at(-1).title, "Focus session complete");
    chrome.alarms.onAlarm.listeners[0]({name: "perseva-boundary"}); await flush();
    await msg("GET_STATUS");
    assert.equal(notifications.length, before + 1);
  });
  await test("blocked page can open only the configured Perseva URL", async () => {
    const result = await msg("OPEN_APP", {url: "chrome-extension://test/blocked.html", tab: {id: 4}});
    assert.equal(result.ok, true); assert.equal(opened.at(-1).url, "https://perseva-study.prottushislam17.chatgpt.site/");
  });
  console.log(`${count} background integration test groups passed.`);
})().catch(error => {console.error(error); process.exitCode = 1;});
