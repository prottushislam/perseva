"use strict";
(() => {
  if (!PERSEVA_APP_ORIGINS.includes(location.origin) || window.top !== window) return;
  const reply = payload => window.postMessage({source: "perseva-extension", type: "STATUS", payload}, location.origin);
  window.addEventListener("message", async event => {
    if (event.source !== window || event.origin !== location.origin || !event.data || event.data.source !== "perseva-app" || !["SYNC", "PING"].includes(event.data.type)) return;
    try {
      const payload = event.data.type === "SYNC" ? PersevaCore.normalizeSync(event.data.payload) : undefined;
      const response = await chrome.runtime.sendMessage({type: event.data.type, ...(payload ? {payload} : {})});
      if (!response?.ok) throw new Error(response?.error || "No extension response.");
      reply(response.payload);
    } catch (error) {
      try {
        const status = await chrome.runtime.sendMessage({type: "PING"});
        reply({...status.payload, error: String(error.message || error)});
      } catch (_) { reply({connected: false, active: false, error: "Reload this app tab to reconnect the extension."}); }
    }
  });
})();
