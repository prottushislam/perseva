"use strict";
(() => {
  const SERVICES = ["youtube", "instagram", "facebook", "tiktok"];
  const DEFAULT_BLOCKING = Object.freeze({youtube: true, instagram: true, facebook: true, tiktok: true});
  const isObject = value => value !== null && typeof value === "object" && !Array.isArray(value);
  function onlyKeys(value, keys, label) {
    if (!isObject(value) || Object.keys(value).some(key => !keys.includes(key))) throw new Error(`${label} has invalid fields.`);
  }
  function string(value, name, max = 120) {
    if (typeof value !== "string" || !value.trim() || value.length > max) throw new Error(`${name} must be a short, nonempty text value.`);
    return value.trim();
  }
  function bool(value, name) {
    if (typeof value !== "boolean") throw new Error(`${name} must be true or false.`);
    return value;
  }
  function minutes(value) {
    if (typeof value !== "string" || !/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(value)) throw new Error("Use a valid HH:mm time.");
    const [hour, minute] = value.split(":").map(Number);
    return hour * 60 + minute;
  }
  function normalizeSync(value, now = Date.now()) {
    onlyKeys(value, ["routines", "blocking", "session"], "Settings");
    if (!Array.isArray(value.routines) || value.routines.length > 100) throw new Error("Provide at most 100 routines.");
    const ids = new Set();
    const routines = value.routines.map(item => {
      onlyKeys(item, ["id", "subject", "start", "end", "days", "enabled", "block", "remind"], "Routine");
      const id = string(item.id, "Routine ID", 100);
      if (ids.has(id)) throw new Error("Routine IDs must be unique.");
      ids.add(id);
      if (minutes(item.end) <= minutes(item.start)) throw new Error("A routine must finish after it starts on the same day.");
      if (!Array.isArray(item.days) || !item.days.length || item.days.length > 7 || item.days.some(day => !Number.isInteger(day) || day < 0 || day > 6) || new Set(item.days).size !== item.days.length) throw new Error("Select unique weekdays from 0 through 6.");
      return {id, subject: string(item.subject, "Subject"), start: item.start, end: item.end, days: [...item.days].sort(), enabled: bool(item.enabled, "Enabled"), block: bool(item.block, "Blocking"), remind: bool(item.remind, "Reminder")};
    });
    onlyKeys(value.blocking, SERVICES, "Blocking settings");
    const blocking = Object.fromEntries(SERVICES.map(key => [key, bool(value.blocking[key], key)]));
    let session = null;
    if (value.session !== null) {
      onlyKeys(value.session, ["endsAt", "subject", "startedAt", "duration"], "Session");
      const {endsAt, startedAt, duration} = value.session;
      if (!Number.isFinite(endsAt) || endsAt <= 0 || endsAt > now + 7 * 86400000) throw new Error("Session deadline must be within seven days.");
      if (startedAt !== undefined && (!Number.isFinite(startedAt) || startedAt <= 0 || startedAt > endsAt)) throw new Error("Invalid session start.");
      if (duration !== undefined && (!Number.isFinite(duration) || duration < 0 || duration > 1e9)) throw new Error("Invalid session duration.");
      const subject = string(value.session.subject, "Session subject");
      if (endsAt > now) session = {endsAt, subject};
    }
    return {routines, blocking, session};
  }
  function defaults() { return {routines: [], blocking: {...DEFAULT_BLOCKING}, session: null, notified: {}, lastSyncedAt: null}; }
  function occurrence(routine, day) {
    const start = new Date(day); start.setHours(0, 0, 0, 0); start.setMinutes(minutes(routine.start));
    const end = new Date(day); end.setHours(0, 0, 0, 0); end.setMinutes(minutes(routine.end));
    return {start: start.getTime(), end: end.getTime(), key: `${routine.id}:${start.getTime()}`};
  }
  function evaluate(state, now = Date.now()) {
    const today = new Date(now), activeRoutines = [], upcoming = [];
    for (const routine of state.routines) {
      if (!routine.enabled) continue;
      for (let offset = 0; offset <= 7; offset++) {
        const day = new Date(today); day.setDate(day.getDate() + offset);
        if (!routine.days.includes(day.getDay())) continue;
        const slot = occurrence(routine, day);
        if (slot.start <= now && now < slot.end) activeRoutines.push({...routine, ...slot});
        if (slot.start > now) upcoming.push(slot.start);
        if (slot.end > now) upcoming.push(slot.end);
      }
    }
    const session = state.session && state.session.endsAt > now ? state.session : null;
    if (session) upcoming.push(session.endsAt);
    const reasons = activeRoutines.filter(routine => routine.block).map(routine => ({subject: routine.subject, endsAt: routine.end, type: "routine"}));
    if (session) reasons.push({...session, type: "session"});
    const active = reasons.length > 0 && SERVICES.some(key => state.blocking[key]);
    return {active, reasons, session, activeRoutines, activeUntil: active ? Math.max(...reasons.map(reason => reason.endsAt)) : null, nextChange: upcoming.length ? Math.min(...upcoming) : null};
  }
  function getService(rawUrl) {
    try {
      const url = new URL(rawUrl);
      if (!["http:", "https:"].includes(url.protocol)) return null;
      for (const service of SERVICES) if (url.hostname === `${service}.com` || url.hostname.endsWith(`.${service}.com`)) return service;
    } catch (_) {}
    return null;
  }
  function blockedService(rawUrl, blocking) {
    const service = getService(rawUrl);
    if (!service || !blocking[service]) return null;
    if (service === "tiktok") return service;
    const url = new URL(rawUrl);
    let path = url.pathname;
    try { path = decodeURIComponent(path); } catch (_) {}
    return (service === "youtube" ? /^\/shorts(?:\/|$)/i : /^\/reels?(?:\/|$)/i).test(path) ? service : null;
  }
  function buildRules(blocking, active) {
    if (!active) return [];
    return SERVICES.filter(service => blocking[service]).map(service => ({
      id: 100 + SERVICES.indexOf(service), priority: 1,
      action: {type: "redirect", redirect: {extensionPath: `/blocked.html?service=${service}`}},
      condition: {
        requestDomains: [`${service}.com`], resourceTypes: ["main_frame"],
        ...(service === "tiktok" ? {} : {regexFilter: `^https?://([a-z0-9-]+\\.)*${service}\\.com/${service === "youtube" ? "shorts" : "reels?"}([/?#]|$)`})
      }
    }));
  }
  const api = {SERVICES, DEFAULT_BLOCKING, defaults, normalizeSync, evaluate, getService, blockedService, buildRules, minutes};
  globalThis.PersevaCore = Object.freeze(api);
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})();
